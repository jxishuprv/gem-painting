module.exports = {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      fontFamily: {
        y2k: ["'Tilt Prism'", "cursive"]
      },
      colors: {
        wine: "#6B2737",
        leopard: "#D4AF37"
      }
    }
  },
  plugins: []
}