
import React, { useState, useRef } from "react";
import Cropper from "react-easy-crop";
import html2canvas from "html2canvas";
import quantize from "quantize";

export default function GemPaintingApp() {
  const [image, setImage] = useState(null);
  const [crop, setCrop] = useState({ x: 0, y: 0 });
  const [zoom, setZoom] = useState(1);
  const [croppedAreaPixels, setCroppedAreaPixels] = useState(null);
  const [gridData, setGridData] = useState([]);
  const [canvasSize, setCanvasSize] = useState({ width: 50, height: 50 });
  const [aspectRatio, setAspectRatio] = useState(1);
  const [colorPreviewUrl, setColorPreviewUrl] = useState(null);
  const inputRef = useRef(null);

  const handleImageUpload = (e) => {
    const file = e.target.files[0];
    const reader = new FileReader();
    reader.onloadend = () => {
      setImage(reader.result);
    };
    reader.readAsDataURL(file);
  };

  const onCropComplete = (_, croppedPixels) => {
    setCroppedAreaPixels(croppedPixels);
  };

  const createGrid = async () => {
    if (!image || !croppedAreaPixels) return;

    const img = new Image();
    img.src = image;
    await new Promise((resolve) => (img.onload = resolve));

    const canvas = document.createElement("canvas");
    canvas.width = canvasSize.width;
    canvas.height = canvasSize.height;
    const ctx = canvas.getContext("2d");

    ctx.drawImage(
      img,
      croppedAreaPixels.x,
      croppedAreaPixels.y,
      croppedAreaPixels.width,
      croppedAreaPixels.height,
      0,
      0,
      canvas.width,
      canvas.height
    );

    const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const pixels = [];
    for (let i = 0; i < imgData.data.length; i += 4) {
      const r = imgData.data[i];
      const g = imgData.data[i + 1];
      const b = imgData.data[i + 2];
      pixels.push([r, g, b]);
    }

    const cmap = quantize(pixels, 40);
    const palette = cmap.palette();

    const mapPixel = (pixel) => {
      let closest = palette[0];
      let minDist = Infinity;
      for (const color of palette) {
        const dist =
          (pixel[0] - color[0]) ** 2 +
          (pixel[1] - color[1]) ** 2 +
          (pixel[2] - color[2]) ** 2;
        if (dist < minDist) {
          minDist = dist;
          closest = color;
        }
      }
      return closest;
    };

    const grid = [];
    let index = 0;
    for (let y = 0; y < canvas.height; y++) {
      const row = [];
      for (let x = 0; x < canvas.width; x++) {
        const pixel = pixels[index++];
        const hex = rgbToHex(...mapPixel(pixel));
        row.push(hex);
      }
      grid.push(row);
    }
    setGridData(grid);

    // Colored zone preview
    const previewCanvas = document.createElement("canvas");
    previewCanvas.width = canvas.width * 10;
    previewCanvas.height = canvas.height * 10;
    const pctx = previewCanvas.getContext("2d");

    for (let y = 0; y < canvas.height; y++) {
      for (let x = 0; x < canvas.width; x++) {
        pctx.fillStyle = grid[y][x];
        pctx.fillRect(x * 10, y * 10, 10, 10);
      }
    }
    const previewURL = previewCanvas.toDataURL();
    setColorPreviewUrl(previewURL);
  };

  const rgbToHex = (r, g, b) =>
    "#" + [r, g, b].map((x) => x.toString(16).padStart(2, "0")).join("");

  return (
    <div className="min-h-screen bg-gradient-to-br from-wine to-black text-leopard p-6 font-y2k">
      <h1 className="text-4xl font-bold text-center mb-6">Create Your Gem Painting Template</h1>

      {!image && (
        <div className="border-4 border-dashed border-leopard p-10 text-center bg-white/10">
          <p className="mb-4">Upload or drag an image to begin:</p>
          <input type="file" accept="image/*" onChange={handleImageUpload} ref={inputRef} />
        </div>
      )}

      {image && (
        <>
          <div className="mb-4">
            <label className="mr-2">Frame Aspect Ratio:</label>
            <select
              className="bg-white text-black px-2 py-1 rounded"
              value={aspectRatio}
              onChange={(e) => setAspectRatio(Number(e.target.value))}
            >
              <option value={1}>1:1</option>
              <option value={4 / 3}>4:3</option>
              <option value={3 / 4}>3:4</option>
              <option value={16 / 9}>16:9</option>
            </select>
          </div>

          <div className="relative w-[300px] h-[300px] mb-6">
            <Cropper
              image={image}
              crop={crop}
              zoom={zoom}
              aspect={aspectRatio}
              onCropChange={setCrop}
              onZoomChange={setZoom}
              onCropComplete={onCropComplete}
            />
          </div>

          <button
            onClick={createGrid}
            className="bg-leopard text-wine px-6 py-2 rounded-full font-bold shadow-lg"
          >
            Generate Templates
          </button>
        </>
      )}

      {gridData.length > 0 && (
        <>
          <h2 className="text-2xl font-bold mt-8 mb-2">🧩 Printable Hex Grid</h2>
          <div className="overflow-auto border border-leopard">
            <div
              className="grid"
              style={{ gridTemplateColumns: `repeat(${canvasSize.width}, 1fr)` }}
            >
              {gridData.flat().map((color, idx) => (
                <div
                  key={idx}
                  title={color}
                  className="w-4 h-4 text-[6px] border border-gray-400"
                  style={{ backgroundColor: color }}
                />
              ))}
            </div>
          </div>

          <h2 className="text-2xl font-bold mt-8 mb-2">🎨 Color Zone Preview</h2>
          {colorPreviewUrl && <img src={colorPreviewUrl} alt="Color Preview" className="shadow-xl border-4 border-leopard" />}

          <h2 className="text-2xl font-bold mt-8 mb-2">🖼️ Finished Image</h2>
          <img
            src={image}
            alt="Original Upload"
            className="max-w-full border-4 border-wine shadow-lg"
          />
        </>
      )}
    </div>
  );
}
